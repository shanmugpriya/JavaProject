import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.TableCellRenderer;

import java.sql.*;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Date.*;
public class report extends JFrame 
{
	PreparedStatement ps;
	Connection con;
	ResultSet rs;
	Statement st;
	JLabel l1;
	String bn,ba,bc,mn;
	int bid,mid;
	Date d1,d2;
    int rows = 0;
	Object data1[][];
	JScrollPane scroller;
	JTable table;
	  
	  
    public report()
    {
    	
     
            Container cp = getContentPane();
    		cp.setLayout(new BorderLayout());
   			
   			 setSize(600,600);
    		 setLocation(50,50);
   		     setLayout(new BorderLayout());
   			 setTitle("Student Details");
   		
   	    	
		
			try{
					con = DatabaseConnection.getConnection();
			}catch(Exception e){e.printStackTrace();}
		
		
		try {
			st = con.createStatement ();	//Creating Statement Object.
		}
		catch (SQLException sqlex) {			//If Problem then Show the User a Message.
 			JOptionPane.showMessageDialog (null, "A Problem Occurs While Loading Form.");
 			dispose ();				//Closing the Form.
	 	}
    
    	
    	
    	try{
    	
			
    	    rs=st.executeQuery("select * from student");
	    	while(rs!=null && rs.next())
	    	{
	    	  rows++;
	    	
	    	}  
    		
				data1=new Object[rows][18];
				
				 rs=st.executeQuery("Select * from student");
				 Object[] Colheads={"usn","student_category","name","gender",
						 "dob", "student_contact_number", "email_id", "house_address", "qualification", "father_name", 
				"father_contact_number", "institute_address", "from_loc", "transit_loc", "to_loc", "pass_type","pass_status","Button"};
				for(int i1=0;i1<rows;i1++)
				{
					
						rs.next();
					    for(int j1=0;j1<18;j1++)
						{
							//System.out.println(j1+1);
					    	if(j1==16)
					    	{
					    		int status_id = rs.getInt(j1+1);
					    		if(status_id==1)
					    			{
					    			data1[i1][j1]="Pending";
					    			}
					    		else if(status_id==2)
					    		{
					    			data1[i1][j1]="Approved";
					    		}
					    		else if(status_id==3)
					    		{
					    			data1[i1][j1]="Rejected";
					    		}
					    		
					    		System.out.println("i1 ="+i1+",j1 = "+j1+"======"+status_id);
					    	}
					    	else if(j1==17)
					    		{
					    		System.out.println("button "+j1);
					    		//TableCellRenderer buttonRenderer = new JTableButtonRenderer();
					            //table.getColumn("Button1").setCellRenderer(buttonRenderer);
					    		//table.getColumn("Button").setCellRenderer(new RadioButtonRenderer()); 
					    		
					    		
								//data1[i1][j1] = table.getColumn("Button").setCellRenderer(new RadioButtonRenderer());;
								//contentPane.add(comboBox1);
					    		}
					    	else
					    	{
					    		System.out.println("i1 ="+i1+",j1 = "+j1+"======"+rs.getString(j1+1));
								data1[i1][j1]=rs.getString(j1+1);
					    	}
							
						}
							
						
				}
				System.out.println("kkkkkkkk ");
				JTable table=new JTable(data1,Colheads);
				int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
				int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
				
				JScrollPane jsp=new JScrollPane(table,v,h);
				
		
			 getContentPane().add(jsp);
		
    		}catch(Exception e)
    	{
    	}
    
    try{
    	//data1=new Object[rows][8];
    	data1=new Object[rows][17];
				//Object[] Colheads={"BookId","BookName","BookAuthor"};
    	//Object[] Colheads={"CUST_ID","NAME","AGE"};
    	 Object[] Colheads={"usn","student_category","name","gender",
				 "dob", "student_contact_number", "email_id", "house_address", "qualification", "father_name", 
		"father_contact_number", "institute_address", "from_loc", "transit_loc", "to_loc", "pass_type","pass_status"};
	
				 rs=st.executeQuery("Select * from student");
				
				for(int i1=0;i1<rows;i1++)
				{ 
						//rs.next();
						for(int j1=0;j1<17;j1++)
						{
							System.out.println(rs.getString(j1+1));
							data1[i1][j1]=rs.getString(j1+1);
						}
				}
				JTable table=new JTable(data1,Colheads);
				int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
				int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
				
				JScrollPane jsp=new JScrollPane(table,v,h);
				
			
				getContentPane().add(jsp);
    }
    catch(Exception e){
    }
    	
    	
    	setVisible(true);
    	//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
    }
    public static void main(String args[])
    {
     JFrame frm = new report();
       			 frm.setSize(600, 600);
       			 frm.setLocation(50,50);
       			 Image image = null;
        try {
           
        	image = ImageIO.read(frm.getClass().getResource("images/test.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        frm.setIconImage(image);
       			 frm.setVisible(true);
       			 frm.show();
    }
    
 }