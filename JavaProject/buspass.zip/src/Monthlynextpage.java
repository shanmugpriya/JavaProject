import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Monthlynextpage extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Monthlynextpage frame = new Monthlynextpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Monthlynextpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(800,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblEmployeePass = new JLabel("MONTHLY PASS ");
		lblEmployeePass.setForeground(new Color(153, 0, 51));
		lblEmployeePass.setFont(new Font("Footlight MT Light", Font.BOLD, 50));
		lblEmployeePass.setBounds(156, 24, 425, 67);
		contentPane.add(lblEmployeePass);
		
		JButton button = new JButton("BACK");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Homepage window = new Homepage();
				window.frame.setVisible(true);
				dispose();
			}
		});
		button.setFont(new Font("Footlight MT Light", Font.BOLD, 25));
		button.setBounds(10, 11, 114, 40);
		contentPane.add(button);
		
		JLabel lblToApplyFor = new JLabel("To Apply for MonthlyPass");
		lblToApplyFor.setForeground(Color.BLACK);
		lblToApplyFor.setFont(new Font("Microsoft Himalaya", Font.BOLD, 45));
		lblToApplyFor.setBounds(58, 174, 460, 40);
		contentPane.add(lblToApplyFor);
		
		JLabel label_2 = new JLabel("To Track Your Pass");
		label_2.setForeground(Color.BLACK);
		label_2.setFont(new Font("Microsoft Himalaya", Font.BOLD, 45));
		label_2.setBounds(58, 267, 330, 59);
		contentPane.add(label_2);
		
		JButton button_1 = new JButton("Click Here!!");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Monthlyform Monthlyform = new Monthlyform();
				Monthlyform.setVisible(true);
			}
		});
		button_1.setFont(new Font("Microsoft Himalaya", Font.BOLD, 28));
		button_1.setBounds(528, 175, 165, 40);
		contentPane.add(button_1);
		
		JButton button_2 = new JButton("Click Here!!");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				monthlytraclpass frame = new monthlytraclpass();
				frame.setVisible(true);
			}
		});
		button_2.setFont(new Font("Microsoft Himalaya", Font.BOLD, 28));
		button_2.setBounds(398, 267, 165, 40);
		contentPane.add(button_2);
	}

}
