import java.awt.Component;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;

public class Monthlylogin extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * 
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Monthlylogin frame = new Monthlylogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Monthlylogin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 774, 483);
		setSize(800,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.setFont(new Font("Footlight MT Light", Font.BOLD, 25));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Adminlog frame = new Adminlog();
				frame.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton.setBounds(10, 46, 128, 47);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("USERNAME");
		lblNewLabel.setForeground(new Color(255, 215, 0));
		lblNewLabel.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 29));
		lblNewLabel.setBounds(175, 214, 206, 39);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setForeground(new Color(255, 215, 0));
		lblNewLabel_1.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 29));
		lblNewLabel_1.setBounds(175, 309, 220, 33);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(416, 214, 174, 33);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(416, 309, 174, 32);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("LOGIN");
		btnNewButton_1.setForeground(new Color(178, 34, 34));
		btnNewButton_1.setFont(new Font("Copperplate Gothic Bold", Font.BOLD, 18));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				String uname = textField.getText();
				String psd = textField_1.getText();
				
				if(uname.equals("Admin") && psd.equals("Employee"))
					{
					Component frame = null;
					JOptionPane.showMessageDialog(frame, "Logged in Successfully");
					}
				else
				{
					Component frame = null;
					JOptionPane.showMessageDialog(frame, "Login Unsuccessful");
					
				}
			}
		});
		btnNewButton_1.setBounds(416, 396, 139, 39);
		contentPane.add(btnNewButton_1);
	}

}
