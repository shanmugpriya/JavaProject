import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import com.toedter.calendar.JDateChooser;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;

public class Monthlyform extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Monthlyform frame = new Monthlyform();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Monthlyform() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(1000,800);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Please Fill in the Below Details");
		lblNewLabel.setBounds(36, 38, 197, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Identity Number");
		lblNewLabel_1.setBounds(36, 95, 112, 16);
		contentPane.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(146, 92, 116, 22);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setBounds(346, 95, 56, 16);
		contentPane.add(lblNewLabel_2);
		
		textField_1 = new JTextField();
		textField_1.setBounds(397, 92, 116, 22);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Sector");
		lblNewLabel_3.setBounds(591, 95, 56, 16);
		contentPane.add(lblNewLabel_3);
		
		JComboBox<String> comboBox = new JComboBox<String>();
		comboBox.addItem("Private");
		comboBox.addItem("Government");
		comboBox.setBounds(659, 92, 105, 22);
		contentPane.add(comboBox);
		
		JLabel lblNewLabel_4 = new JLabel("Gender");
		lblNewLabel_4.setBounds(48, 214, 56, 16);
		contentPane.add(lblNewLabel_4);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("Male");
		rdbtnNewRadioButton.setBounds(92, 210, 78, 25);
		contentPane.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("Female");
		rdbtnNewRadioButton_1.setBounds(92, 239, 86, 25);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("Others");
		rdbtnNewRadioButton_2.setBounds(92, 269, 78, 25);
		contentPane.add(rdbtnNewRadioButton_2);
		
		JLabel lblNewLabel_5 = new JLabel("Dob");
		lblNewLabel_5.setBounds(227, 214, 56, 16);
		contentPane.add(lblNewLabel_5);
		
		JDateChooser dateChooser = new JDateChooser();
		dateChooser.setBounds(265, 208, 137, 22);
		contentPane.add(dateChooser);
		
		JLabel lblNewLabel_6 = new JLabel("Contact Number");
		lblNewLabel_6.setBounds(478, 214, 105, 16);
		contentPane.add(lblNewLabel_6);
		
		textField_2 = new JTextField();
		textField_2.setBounds(623, 211, 116, 22);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Email id");
		lblNewLabel_7.setBounds(48, 413, 56, 16);
		contentPane.add(lblNewLabel_7);
		
		textField_3 = new JTextField();
		textField_3.setBounds(117, 410, 166, 22);
		contentPane.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("House Address");
		lblNewLabel_8.setBounds(346, 413, 95, 16);
		contentPane.add(lblNewLabel_8);
		
		textField_4 = new JTextField();
		textField_4.setBounds(454, 410, 166, 54);
		contentPane.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("Qualification");
		lblNewLabel_9.setBounds(671, 413, 93, 16);
		contentPane.add(lblNewLabel_9);
		
		textField_6 = new JTextField();
		textField_6.setBounds(758, 410, 116, 22);
		contentPane.add(textField_6);
		textField_6.setColumns(10);
		
		
		JLabel lblNewLabel_10 = new JLabel("Aadhar Number");
		lblNewLabel_10.setBounds(48, 563, 100, 16);
		contentPane.add(lblNewLabel_10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(160, 560, 151, 22);
		contentPane.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_11 = new JLabel("Senior Citizen");
		lblNewLabel_11.setBounds(362, 563, 93, 16);
		contentPane.add(lblNewLabel_11);
		
		JRadioButton rdbtnNewRadioButton_3 = new JRadioButton("Yes");
		rdbtnNewRadioButton_3.setBounds(454, 559, 61, 25);
		contentPane.add(rdbtnNewRadioButton_3);
		
		JRadioButton rdbtnNewRadioButton_4 = new JRadioButton("No");
		rdbtnNewRadioButton_4.setBounds(454, 588, 61, 25);
		contentPane.add(rdbtnNewRadioButton_4);
		
		ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(rdbtnNewRadioButton);
        buttonGroup.add(rdbtnNewRadioButton_1);
        buttonGroup.add(rdbtnNewRadioButton_2);
		
		JLabel lblNewLabel_12 = new JLabel("Pass Type");
		lblNewLabel_12.setBounds(574, 563, 86, 16);
		contentPane.add(lblNewLabel_12);
		
		JComboBox<String> comboBox_2 = new JComboBox<String>();
		comboBox_2.addItem("Monthly");
		comboBox_2.setBounds(671, 560, 93, 22);
		contentPane.add(comboBox_2);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				Monthlynextpage window = new Monthlynextpage();
				//homepage1 window = new homepage1();
				window.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(830, 34, 97, 25);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Submit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				if (e.getSource() == btnNewButton_1)  
		         {  
		            int x = 0;  
		            String Name = textField_1.getText();  
		            String Contact_Number = textField_2.getText(); 
					String House_Address = textField_4.getText();
		            String Email_id = textField_3.getText();
		            String Identity_Number = textField.getText();
		            String Qualification = textField_6.getText();
		            String Aadhar_Number = textField_5.getText();
		            String Gender = buttonGroup.getSelection().getActionCommand();
		            String Senior_Citizen = buttonGroup.getSelection().getActionCommand();
		            String Dob = ((JTextField)dateChooser.getDateEditor().getUiComponent()).getText();
		            String Sector = comboBox.getSelectedItem().toString();
		            String Pass_Type = comboBox_2.getSelectedItem().toString();
		            
		            Monthlyform s = new Monthlyform();
		            if(Dob!=null)
	            	{
	            		Dob = s.convertDate(Dob);
	            	}
		            
		                Connection con;
		                try  
		                {  
		                	con = DatabaseConnection.getConnection();
							PreparedStatement ps = con.prepareStatement("insert into monthly(Identity_Number,Sector,Name,Gender,Dob,Contact_Number,Email_id,House_Address,Qualification,Aadhar_Number,Senior_Citizen,Pass_Type,Pass_Status) values ('"+Identity_Number+"','"+Sector+"','"+Name+"','"+Gender+"','"+Dob+"','"+Contact_Number+"','"+Email_id+"',"+ "'"+House_Address+"','"+Qualification+"','"+Aadhar_Number+"','"+Senior_Citizen+"','"+Pass_Type+"','1')");  
		                   
		                    ps.execute();
		                    
		                    x++;  
		                    if (x > 0)   
		                    {  
		                        JOptionPane.showMessageDialog(btnNewButton_1, "Data Saved Successfully"); 
		                        Studform.mailSending(Email_id,Name);
		                    }  
		                }  
		                catch (Exception ex)   
		                {  
		                    System.out.println(ex);  
		                }  
		            }  
		            else  
		            {  
		                JOptionPane.showMessageDialog(btnNewButton_1, "Password Does Not Match");  
		            }   
		          }   
		});
		btnNewButton_1.setBounds(809, 667, 97, 25);
		contentPane.add(btnNewButton_1);
	}
		
		
		
		
				
			
		
				



public String convertDate(String strDate)
{ 
   try
   {
     //create SimpleDateFormat object with source string date format
     SimpleDateFormat sdfSource = new SimpleDateFormat("dd MMM,yyyy");
     
     //parse the string into Date object
     Date date = sdfSource.parse(strDate);
     
     //create SimpleDateFormat object with desired date format
     SimpleDateFormat sdfDestination = new SimpleDateFormat("yyyy-MM-dd");
     
     //parse the date into another format
     strDate = sdfDestination.format(date);
    
    // return strDate;
   }
   catch(ParseException pe)
   { 
     System.out.println("Parse Exception : " + pe);
   }
   return strDate;
 }

public static void mailSending(String reciever,String user)
{
	
	 String subject="Bus Pass Registration";
	 String sender="transit.passapp@gmail.com";
	 String password="transit123#";
	 
	 
	 String message = "Hello "+user+" !!\r\n" + 
	 		"Your Registration form for the Bus Pass is Accepted.\r\n" + 
	 		"To Track your Pass and know the details for it,\r\n" + 
	 		"Click on Track Student Pass in the website and enter,\r\n" + 
	 		"Username(your name)\r\n" + 
	 		"Password(your identity number)\r\n" + 
	 		"Thank You!!";
    Mailer.send(sender,password,reciever,subject,message);
}
public void actionPerformed(ActionEvent e) {
	
}
}





