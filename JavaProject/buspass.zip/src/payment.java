import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JTextField;
import com.toedter.calendar.JMonthChooser;
import com.toedter.calendar.JYearChooser;

public class payment extends JFrame {

	private JPanel contentPane;
	private JPanel contentPane1;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					payment frame = new payment();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public payment()
	{JFrame frame;
		 Container contentPane = getContentPane();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(1000,750);
		contentPane = new JPanel();
		//contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("BACK");
		btnNewButton_2.setFont(new Font("Footlight MT Light", Font.BOLD, 25));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				studtrackpass window = new studtrackpass();
				window.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(22, 11, 114, 40);
		contentPane.add(btnNewButton_2);
		 
		
		JLabel lblNewLabel = new JLabel("Choose the Payment Mode");
		lblNewLabel.setBounds(41, 105, 172, 28);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("CREDIT CARD");
		
		
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource() == btnNewButton)  
		         {  
					payment p = new payment();
					p.CreditCardpayment();
					p.setVisible(true);
		         }
			}
			});
		
		btnNewButton.setBounds(41, 181, 147, 25);
		contentPane.add(btnNewButton);
		
		
		JButton btnNewButton_1 = new JButton("DEBIT CARD");
		btnNewButton_1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				 if (e.getSource() == btnNewButton_1)  
		         {  
					 System.out.println("Hello");
					payment p = new payment();
					p.debitCardpayment();
					p.setVisible(true);
		         }
			}
			});
		btnNewButton_1.setBounds(44, 285, 122, 25);
		contentPane.add(btnNewButton_1);
	}

	/**
	 * Create the frame.
	 */
	public  void CreditCardpayment() {
		 Container contentPane1 = getContentPane();

		contentPane1 = new JPanel();
		//contentPane1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane1);
		contentPane1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Fill in the Card Details");
		lblNewLabel_1.setBounds(348, 111, 157, 16);
		contentPane1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Card Number");
		lblNewLabel_2.setBounds(314, 185, 113, 16);
		contentPane1.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(311, 220, 194, 22);
		contentPane1.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Card Holder's Name");
		lblNewLabel_3.setBounds(314, 289, 147, 16);
		contentPane1.add(lblNewLabel_3);
		
		textField_1 = new JTextField();
		textField_1.setBounds(314, 329, 116, 22);
		contentPane1.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Expiry");
		lblNewLabel_4.setBounds(314, 380, 56, 16);
		contentPane1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("MM");
		lblNewLabel_5.setBounds(322, 423, 31, 16);
		contentPane1.add(lblNewLabel_5);
		
		JMonthChooser monthChooser = new JMonthChooser();
		monthChooser.setBounds(365, 417, 111, 22);
		contentPane1.add(monthChooser);
		
		JLabel lblNewLabel_6 = new JLabel("YYYY");
		lblNewLabel_6.setBounds(507, 423, 56, 16);
		contentPane1.add(lblNewLabel_6);
		
		JYearChooser yearChooser = new JYearChooser();
		yearChooser.setBounds(543, 417, 51, 22);
		contentPane1.add(yearChooser);
	}
	
	/**
	 * Create the frame.
	 */
	public  void debitCardpayment() {
		 Container contentPane1 = getContentPane();

		contentPane1 = new JPanel();
		//contentPane1.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane1);
		contentPane1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Fill in the Card Details");
		lblNewLabel_1.setBounds(348, 111, 157, 16);
		contentPane1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Card Number");
		lblNewLabel_2.setBounds(314, 185, 113, 16);
		contentPane1.add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(311, 220, 194, 22);
		contentPane1.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Card Holder's Name");
		lblNewLabel_3.setBounds(314, 289, 147, 16);
		contentPane1.add(lblNewLabel_3);
		
		textField_1 = new JTextField();
		textField_1.setBounds(314, 329, 116, 22);
		contentPane1.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Expiry");
		lblNewLabel_4.setBounds(314, 380, 56, 16);
		contentPane1.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("MM");
		lblNewLabel_5.setBounds(322, 423, 31, 16);
		contentPane1.add(lblNewLabel_5);
		
		JMonthChooser monthChooser = new JMonthChooser();
		monthChooser.setBounds(365, 417, 111, 22);
		contentPane1.add(monthChooser);
		
		JLabel lblNewLabel_6 = new JLabel("YYYY");
		lblNewLabel_6.setBounds(507, 423, 56, 16);
		contentPane1.add(lblNewLabel_6);
		
		JYearChooser yearChooser = new JYearChooser();
		yearChooser.setBounds(543, 417, 51, 22);
		contentPane1.add(yearChooser);
		
		JLabel lblNewLabel_7 = new JLabel("CVV");
		lblNewLabel_7.setBounds(320, 470, 147, 16);
		contentPane1.add(lblNewLabel_7);
		
		textField_2 = new JTextField();
		textField_2.setBounds(390, 475, 116, 22);
		contentPane1.add(textField_2);
		textField_2.setColumns(10);
	}
}
