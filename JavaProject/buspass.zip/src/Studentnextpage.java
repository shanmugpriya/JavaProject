import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Studentnextpage extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Studentnextpage frame = new Studentnextpage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Studentnextpage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 789, 491);
		setSize(800,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("STUDENT PASS ");
		lblNewLabel.setForeground(new Color(153, 0, 51));
		lblNewLabel.setFont(new Font("Footlight MT Light", Font.BOLD, 50));
		lblNewLabel.setBounds(209, 30, 384, 67);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("To Apply for Student Pass");
		lblNewLabel_1.setForeground(new Color(0, 0, 0));
		lblNewLabel_1.setFont(new Font("Microsoft Himalaya", Font.BOLD, 45));
		lblNewLabel_1.setBounds(63, 178, 460, 40);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Click Here!!");
		btnNewButton.setFont(new Font("Microsoft Himalaya", Font.BOLD, 28));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Studform studform1 = new Studform();
				studform1.setVisible(true);
			}
			
		});
		btnNewButton.setBounds(501, 179, 165, 40);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_2 = new JLabel("To Track Your Pass");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Microsoft Himalaya", Font.BOLD, 45));
		lblNewLabel_2.setBounds(63, 279, 330, 59);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton_1 = new JButton("Click Here!!");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				studtrackpass studtrackpass = new studtrackpass();
				studtrackpass.setVisible(true);

			}
		});
		btnNewButton_1.setFont(new Font("Microsoft Himalaya", Font.BOLD, 28));
		btnNewButton_1.setBounds(403, 289, 165, 40);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("BACK");
		btnNewButton_2.setFont(new Font("Footlight MT Light", Font.BOLD, 25));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Homepage window = new Homepage();
				window.frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(22, 11, 114, 40);
		contentPane.add(btnNewButton_2);
		 
	}
	

}
