import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Contact extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Contact frame = new Contact();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Contact() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		setSize(800,600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Contact Us");
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Footlight MT Light", Font.BOLD, 50));
		lblNewLabel.setBounds(230, 32, 274, 52);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("9426712398");
		lblNewLabel_2.setForeground(new Color(0, 0, 0));
		lblNewLabel_2.setFont(new Font("Footlight MT Light", Font.BOLD, 25));
		lblNewLabel_2.setBounds(252, 144, 174, 40);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("transit.passapp@gmail.com");
		lblNewLabel_4.setFont(new Font("Footlight MT Light", Font.BOLD, 25));
		lblNewLabel_4.setBounds(252, 276, 362, 35);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_6 = new JLabel(" Central offices, NGO Colony, Shanti Nagar, Bengaluru, Karnataka 560027");
		lblNewLabel_6.setFont(new Font("Footlight MT Light", Font.BOLD, 15));
		lblNewLabel_6.setBounds(230, 406, 544, 65);
		contentPane.add(lblNewLabel_6);
		
		JButton btnNewButton = new JButton("BACK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				Homepage window = new Homepage();
				window.frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Footlight MT Light", Font.BOLD, 25));
		btnNewButton.setBounds(10, 22, 114, 35);
		contentPane.add(btnNewButton);
	}
}
